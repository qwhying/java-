整理人 qiaoger@126.com
2018年10月13日

一、知识点
Java Servlet 是运行在 Web 服务器或应用服务器上的程序，它是作为来自 Web 浏览器或
其他 HTTP 客户端的请求和 HTTP 服务器上的数据库或应用程序之间的中间层。

简单的说java的web开发都是基于Servlet的，这是最本质的意思。

所以JavaEE开发人员对Servlet要有基本的了解。

web.xml 中Servlet的配置要掌握

二、开发环境
1、jdk1.8
2、tomcat-8.0.29
3、IntelliJ IDEA